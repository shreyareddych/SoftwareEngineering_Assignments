
# calculator_bad.py
# Violates: KISS, DRY, Separation of Concerns, Single Responsibility, Clean Code

# everything is global
x = 0
y = 0
op = ""

def doEverything():
    # giant function that does input, logic, and output all at once
    print("Welcome to calc")
    global x, y, op
    try:
        x = float(input("Enter number 1: "))
    except:
        print("ok whatever using 0")
        x = 0
    try:
        y = float(input("Enter number 2: "))
    except:
        print("ok whatever using 0")
        y = 0
    op = input("Enter operation (+, -, *, /): ")
    if op == "+":
        # repeated logic, no reuse
        r = x + y
        print("Result is " + str(r))
        return r
    else:
        if op == "-":
            r = x - y
            print("Result is " + str(r))
            return r
        else:
            if op == "*":
                r = x * y
                print("Result is " + str(r))
                return r
            else:
                if op == "/":
                    if y == 0:
                        print("idk NaN?")
                        return "NaN"
                    r = x / y
                    print("Result is " + str(r))
                    return r
                else:
                    print("no idea what you typed")
                    return None

# run immediately on import (bad)
doEverything()
