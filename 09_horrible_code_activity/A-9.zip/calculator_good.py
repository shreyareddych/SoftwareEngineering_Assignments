
# calculator_good.py
# Demonstrates: KISS, DRY, Separation of Concerns, Single Responsibility, Clean Code
# Also: documented functions, clear names, explicit main guard

from typing import Callable

def add(a: float, b: float) -> float:
    """Return the sum of a and b."""
    return a + b

def subtract(a: float, b: float) -> float:
    """Return the difference of a and b."""
    return a - b

def multiply(a: float, b: float) -> float:
    """Return the product of a and b."""
    return a * b

def divide(a: float, b: float) -> float:
    """Return a divided by b. Raises ValueError on division by zero."""
    if b == 0:
        raise ValueError("Division by zero")
    return a / b

OPERATIONS: dict[str, Callable[[float, float], float]] = {
    "+": add,
    "-": subtract,
    "*": multiply,
    "/": divide,
}

def parse_number(prompt: str) -> float:
    """Read a float from input with a simple retry loop."""
    while True:
        try:
            return float(input(prompt).strip())
        except ValueError:
            print("Please enter a valid number.")

def choose_operation() -> str:
    """Ask the user to choose an operation symbol."""
    while True:
        op = input("Enter operation (+, -, *, /): ").strip()
        if op in OPERATIONS:
            return op
        print("Choose one of +, -, *, /.")

def main() -> None:
    print("Simple Calculator")
    a = parse_number("Enter number 1: ")
    b = parse_number("Enter number 2: ")
    op = choose_operation()
    try:
        result = OPERATIONS[op](a, b)
        print(f"Result: {result}")
    except ValueError as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    main()
