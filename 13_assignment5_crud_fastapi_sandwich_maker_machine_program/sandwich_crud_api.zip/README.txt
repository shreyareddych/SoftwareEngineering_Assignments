
FastAPI CRUD - Sandwich Maker Machine Program

1) Create MySQL DB:
   CREATE DATABASE sandwich_maker_api;

2) Edit api/dependencies/config.py with your MySQL username/password.

3) Install deps:
   pip install -r requirements.txt

4) Run:
   uvicorn api.main:app --reload

5) Open docs:
   http://127.0.0.1:8000/docs
