
from sqlalchemy.orm import Session
from ..models import models, schemas

def create(db: Session, payload: schemas.ResourceCreate):
    obj = models.Resource(**payload.model_dump())
    db.add(obj)
    db.commit()
    db.refresh(obj)
    return obj

def read_all(db: Session):
    return db.query(models.Resource).all()

def read_one(db: Session, id: int):
    return db.query(models.Resource).filter(models.Resource.id == id).first()

def update(db: Session, id: int, payload: schemas.ResourceUpdate):
    q = db.query(models.Resource).filter(models.Resource.id == id)
    data = payload.model_dump(exclude_unset=True)
    q.update(data, synchronize_session=False)
    db.commit()
    return q.first()

def delete(db: Session, id: int):
    q = db.query(models.Resource).filter(models.Resource.id == id)
    q.delete(synchronize_session=False)
    db.commit()
    return True
