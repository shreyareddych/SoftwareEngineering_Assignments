
# Set your MySQL credentials here
MYSQL_USER = "root"
MYSQL_PASSWORD = "password"
MYSQL_HOST = "127.0.0.1"
MYSQL_PORT = 3306
MYSQL_DB = "sandwich_maker_api"
