
from fastapi import FastAPI, Depends, HTTPException, status
from sqlalchemy.orm import Session
from .dependencies.database import Base, engine, get_db
from .models import schemas
from .controllers import sandwiches, resources, recipes, orders, orderdetails

app = FastAPI(title="Sandwich Maker CRUD API")

# Create tables
Base.metadata.create_all(bind=engine)

# Sandwiches
@app.post("/sandwiches/", response_model=schemas.Sandwich, tags=["Sandwiches"])
def create_sandwich(payload: schemas.SandwichCreate, db: Session = Depends(get_db)):
    return sandwiches.create(db, payload)

@app.get("/sandwiches/", response_model=list[schemas.Sandwich], tags=["Sandwiches"])
def read_sandwiches(db: Session = Depends(get_db)):
    return sandwiches.read_all(db)

@app.get("/sandwiches/{id}", response_model=schemas.Sandwich, tags=["Sandwiches"])
def read_one_sandwich(id: int, db: Session = Depends(get_db)):
    obj = sandwiches.read_one(db, id)
    if not obj:
        raise HTTPException(status_code=404, detail="Sandwich not found")
    return obj

@app.put("/sandwiches/{id}", response_model=schemas.Sandwich, tags=["Sandwiches"])
def update_sandwich(id: int, payload: schemas.SandwichUpdate, db: Session = Depends(get_db)):
    obj = sandwiches.update(db, id, payload)
    if not obj:
        raise HTTPException(status_code=404, detail="Sandwich not found")
    return obj

@app.delete("/sandwiches/{id}", status_code=status.HTTP_204_NO_CONTENT, tags=["Sandwiches"])
def delete_sandwich(id: int, db: Session = Depends(get_db)):
    if not sandwiches.read_one(db, id):
        raise HTTPException(status_code=404, detail="Sandwich not found")
    sandwiches.delete(db, id)
    return None

# Resources
@app.post("/resources/", response_model=schemas.Resource, tags=["Resources"])
def create_resource(payload: schemas.ResourceCreate, db: Session = Depends(get_db)):
    return resources.create(db, payload)

@app.get("/resources/", response_model=list[schemas.Resource], tags=["Resources"])
def read_resources(db: Session = Depends(get_db)):
    return resources.read_all(db)

@app.get("/resources/{id}", response_model=schemas.Resource, tags=["Resources"])
def read_one_resource(id: int, db: Session = Depends(get_db)):
    obj = resources.read_one(db, id)
    if not obj:
        raise HTTPException(status_code=404, detail="Resource not found")
    return obj

@app.put("/resources/{id}", response_model=schemas.Resource, tags=["Resources"])
def update_resource(id: int, payload: schemas.ResourceUpdate, db: Session = Depends(get_db)):
    obj = resources.update(db, id, payload)
    if not obj:
        raise HTTPException(status_code=404, detail="Resource not found")
    return obj

@app.delete("/resources/{id}", status_code=status.HTTP_204_NO_CONTENT, tags=["Resources"])
def delete_resource(id: int, db: Session = Depends(get_db)):
    if not resources.read_one(db, id):
        raise HTTPException(status_code=404, detail="Resource not found")
    resources.delete(db, id)
    return None

# Recipes
@app.post("/recipes/", response_model=schemas.Recipe, tags=["Recipes"])
def create_recipe(payload: schemas.RecipeCreate, db: Session = Depends(get_db)):
    return recipes.create(db, payload)

@app.get("/recipes/", response_model=list[schemas.Recipe], tags=["Recipes"])
def read_recipes(db: Session = Depends(get_db)):
    return recipes.read_all(db)

@app.get("/recipes/{id}", response_model=schemas.Recipe, tags=["Recipes"])
def read_one_recipe(id: int, db: Session = Depends(get_db)):
    obj = recipes.read_one(db, id)
    if not obj:
        raise HTTPException(status_code=404, detail="Recipe not found")
    return obj

@app.put("/recipes/{id}", response_model=schemas.Recipe, tags=["Recipes"])
def update_recipe(id: int, payload: schemas.RecipeUpdate, db: Session = Depends(get_db)):
    obj = recipes.update(db, id, payload)
    if not obj:
        raise HTTPException(status_code=404, detail="Recipe not found")
    return obj

@app.delete("/recipes/{id}", status_code=status.HTTP_204_NO_CONTENT, tags=["Recipes"])
def delete_recipe(id: int, db: Session = Depends(get_db)):
    if not recipes.read_one(db, id):
        raise HTTPException(status_code=404, detail="Recipe not found")
    recipes.delete(db, id)
    return None

# Orders
@app.post("/orders/", response_model=schemas.Order, tags=["Orders"])
def create_order(payload: schemas.OrderCreate, db: Session = Depends(get_db)):
    return orders.create(db, payload)

@app.get("/orders/", response_model=list[schemas.Order], tags=["Orders"])
def read_orders(db: Session = Depends(get_db)):
    return orders.read_all(db)

@app.get("/orders/{id}", response_model=schemas.Order, tags=["Orders"])
def read_one_order(id: int, db: Session = Depends(get_db)):
    obj = orders.read_one(db, id)
    if not obj:
        raise HTTPException(status_code=404, detail="Order not found")
    return obj

@app.put("/orders/{id}", response_model=schemas.Order, tags=["Orders"])
def update_order(id: int, payload: schemas.OrderUpdate, db: Session = Depends(get_db)):
    obj = orders.update(db, id, payload)
    if not obj:
        raise HTTPException(status_code=404, detail="Order not found")
    return obj

@app.delete("/orders/{id}", status_code=status.HTTP_204_NO_CONTENT, tags=["Orders"])
def delete_order(id: int, db: Session = Depends(get_db)):
    if not orders.read_one(db, id):
        raise HTTPException(status_code=404, detail="Order not found")
    orders.delete(db, id)
    return None

# Order Details
@app.post("/order_details/", response_model=schemas.OrderDetail, tags=["OrderDetails"])
def create_order_detail(payload: schemas.OrderDetailCreate, db: Session = Depends(get_db)):
    # simple server-side price calc example (optional)
    return orderdetails.create(db, payload)

@app.get("/order_details/", response_model=list[schemas.OrderDetail], tags=["OrderDetails"])
def read_order_details(db: Session = Depends(get_db)):
    return orderdetails.read_all(db)

@app.get("/order_details/{id}", response_model=schemas.OrderDetail, tags=["OrderDetails"])
def read_one_order_detail(id: int, db: Session = Depends(get_db)):
    obj = orderdetails.read_one(db, id)
    if not obj:
        raise HTTPException(status_code=404, detail="Order detail not found")
    return obj

@app.put("/order_details/{id}", response_model=schemas.OrderDetail, tags=["OrderDetails"])
def update_order_detail(id: int, payload: schemas.OrderDetailUpdate, db: Session = Depends(get_db)):
    obj = orderdetails.update(db, id, payload)
    if not obj:
        raise HTTPException(status_code=404, detail="Order detail not found")
    return obj

@app.delete("/order_details/{id}", status_code=status.HTTP_204_NO_CONTENT, tags=["OrderDetails"])
def delete_order_detail(id: int, db: Session = Depends(get_db)):
    if not orderdetails.read_one(db, id):
        raise HTTPException(status_code=404, detail="Order detail not found")
    orderdetails.delete(db, id)
    return None
