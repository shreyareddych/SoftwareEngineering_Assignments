
from pydantic import BaseModel
from typing import Optional, List

# Sandwich
class SandwichBase(BaseModel):
    sandwich_size: str
    price: float

class SandwichCreate(SandwichBase): pass

class SandwichUpdate(BaseModel):
    sandwich_size: Optional[str] = None
    price: Optional[float] = None

class Sandwich(SandwichBase):
    id: int
    class Config:
        from_attributes = True

# Resource
class ResourceBase(BaseModel):
    item: str
    amount: int

class ResourceCreate(ResourceBase): pass

class ResourceUpdate(BaseModel):
    item: Optional[str] = None
    amount: Optional[int] = None

class Resource(ResourceBase):
    id: int
    class Config:
        from_attributes = True

# Recipe
class RecipeBase(BaseModel):
    sandwich_size: str
    item: str
    amount: int

class RecipeCreate(RecipeBase): pass

class RecipeUpdate(BaseModel):
    sandwich_size: Optional[str] = None
    item: Optional[str] = None
    amount: Optional[int] = None

class Recipe(RecipeBase):
    id: int
    class Config:
        from_attributes = True

# Order
class OrderBase(BaseModel):
    customer_name: str
    description: Optional[str] = None

class OrderCreate(OrderBase): pass

class OrderUpdate(BaseModel):
    customer_name: Optional[str] = None
    description: Optional[str] = None

class Order(OrderBase):
    id: int
    class Config:
        from_attributes = True

# OrderDetail
class OrderDetailBase(BaseModel):
    order_id: int
    sandwich_id: int
    qty: int
    line_total: float

class OrderDetailCreate(OrderDetailBase): pass

class OrderDetailUpdate(BaseModel):
    order_id: Optional[int] = None
    sandwich_id: Optional[int] = None
    qty: Optional[int] = None
    line_total: Optional[float] = None

class OrderDetail(OrderDetailBase):
    id: int
    class Config:
        from_attributes = True
