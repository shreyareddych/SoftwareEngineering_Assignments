
from bank.savings import SavingsAccount
from bank.checking import CheckingAccount

def scenario():
    chk1 = CheckingAccount("Alice Johnson", 600.0, "1111222233334444", "021000021", daily_transfer_limit=500.0)
    chk2 = CheckingAccount("Bob Smith",   250.0, "5555666677778888", "021000021", daily_transfer_limit=500.0)

    sav1 = SavingsAccount("Alice Johnson", 1000.0, "9999000011112222", "021000021", interest_rate=0.02)
    sav2 = SavingsAccount("Bob Smith",      300.0, "2222333344445555", "021000021", interest_rate=0.03)

    print("\n-- Scenario: withdraw $120 from Alice's checking --")
    chk1.withdraw(120.0)
    chk1.print_customer_information()

    print("\n-- Transfer $200 from Alice's checking to Bob's checking --")
    chk1.transfer(chk2, 200.0)
    chk1.print_customer_information()
    chk2.print_customer_information()

    print("\n-- Apply interest to both savings accounts --")
    sav1.apply_interest()
    sav2.apply_interest()
    sav1.print_customer_information()
    sav2.print_customer_information()

    print("\n-- Attempt to exceed transfer limit (expect error) --")
    try:
        chk1.transfer(chk2, 400.0)
    except ValueError as e:
        print(f"Expected error: {e}")

if __name__ == "__main__":
    scenario()
