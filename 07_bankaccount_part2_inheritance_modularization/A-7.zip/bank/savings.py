
from .base import BankAccount

class SavingsAccount(BankAccount):
    def __init__(self, customer_name: str, opening_balance: float, account_number: str, routing_number: str, interest_rate: float = 0.02):
        super().__init__(customer_name, opening_balance, account_number, routing_number)
        self.interest_rate = float(interest_rate)

    def apply_interest(self) -> float:
        self.balance *= (1.0 + self.interest_rate)
        return self.balance
