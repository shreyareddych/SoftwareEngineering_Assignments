
from __future__ import annotations

class BankAccount:
    bank_title = "Global Trust Bank"

    def __init__(self, customer_name: str, opening_balance: float, account_number: str, routing_number: str):
        self.customer_name = customer_name
        self.balance = float(opening_balance)
        self.__account_number = account_number      # private
        self._routing_number = routing_number       # protected

    @property
    def account_number(self) -> str:
        return f"****{self.__account_number[-4:]}"

    @property
    def routing_number(self) -> str:
        return f"***{self._routing_number[-3:]}"

    def deposit(self, amount: float) -> float:
        if amount <= 0:
            raise ValueError("Deposit must be positive")
        self.balance += amount
        return self.balance

    def withdraw(self, amount: float) -> float:
        if amount <= 0:
            raise ValueError("Withdrawal must be positive")
        if amount > self.balance:
            raise ValueError("Insufficient funds")
        self.balance -= amount
        return self.balance

    def transfer(self, other: "BankAccount", amount: float) -> None:
        self.withdraw(amount)
        other.deposit(amount)

    def print_customer_information(self) -> None:
        print(f"Bank: {self.bank_title}")
        print(f"Customer: {self.customer_name}")
        print(f"Account: {self.account_number}")
        print(f"Routing: {self.routing_number}")
        print(f"Balance: ${self.balance:.2f}")
