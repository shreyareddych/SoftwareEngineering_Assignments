
from .base import BankAccount

class CheckingAccount(BankAccount):
    def __init__(self, customer_name: str, opening_balance: float, account_number: str, routing_number: str, daily_transfer_limit: float = 500.0):
        super().__init__(customer_name, opening_balance, account_number, routing_number)
        self.daily_transfer_limit = float(daily_transfer_limit)
        self._transferred_today = 0.0  # protected

    def reset_daily_limit(self) -> None:
        self._transferred_today = 0.0

    def transfer(self, other: "BankAccount", amount: float) -> None:
        if amount <= 0:
            raise ValueError("Transfer must be positive")
        if self._transferred_today + amount > self.daily_transfer_limit:
            raise ValueError("Transfer limit reached for today")
        super().transfer(other, amount)
        self._transferred_today += amount
