
from typing import Optional
from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI(title="FastAPI Implementation Assignment")

@app.get("/")
def read_root():
    return {"hello": "world"}

@app.get("/items/{item_id}")
def read_item(item_id: int, q: Optional[str] = None):
    return {"item_id": item_id, "q": q}

# Part 2: simple class and PUT request
class Item(BaseModel):
    name: str
    price: float
    is_offer: Optional[bool] = None

@app.put("/items/{item_id}")
def update_item(item_id: int, item: Item, note: Optional[str] = None):
    return {
        "item_id": item_id,
        "item": item.model_dump(),
        "note": note
    }
