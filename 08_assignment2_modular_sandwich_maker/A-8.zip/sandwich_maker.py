
# sandwich_maker.py
# Responsible for making sandwiches from resources and recipes

class SandwichMaker:
    def __init__(self, resources: dict):
        # keep internal copy we can mutate
        self.resources = dict(resources)

    def check_resources(self, ingredients: dict) -> bool:
        for item, needed in ingredients.items():
            if self.resources.get(item, 0) < needed:
                print(f"Sorry there is not enough {item}.")
                return False
        return True

    def make_sandwich(self, sandwich_size: str, order_ingredients: dict) -> None:
        for item, amt in order_ingredients.items():
            self.resources[item] -= amt
        print(f"{sandwich_size} sandwich is ready. Bon appetit!")

    def report(self) -> None:
        print(f"Bread: {self.resources.get('bread', 0)} slice(s)")
        print()
        print(f"Ham: {self.resources.get('ham', 0)} slice(s)")
        print(f"Cheese: {self.resources.get('cheese', 0)} pound(s)")
