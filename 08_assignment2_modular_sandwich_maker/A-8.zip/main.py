
# main.py
# Entry point: imports modules, wires objects, and runs the machine loop

import data
from sandwich_maker import SandwichMaker
from cashier import Cashier

def main():
    recipes = data.recipes
    resources = data.resources

    maker = SandwichMaker(resources)
    cashier = Cashier()

    while True:
        choice = input("What would you like? (small/ medium/ large/ off/ report): ").strip().lower()
        if choice == "off":
            break
        if choice == "report":
            maker.report()
            continue
        if choice not in recipes:
            # ignore invalid command
            continue

        recipe = recipes[choice]
        ingredients = recipe['ingredients']
        cost = recipe['cost']

        # 1) check resources
        if not maker.check_resources(ingredients):
            continue

        # 2) process coins
        coins = cashier.process_coins()

        # 3) transaction
        if not cashier.transaction_result(coins, cost):
            continue

        # 4) make
        maker.make_sandwich(choice, ingredients)

if __name__ == "__main__":
    main()
