
# cashier.py
# Responsible for taking coins and validating transactions

class Cashier:
    def process_coins(self) -> float:
        print("Please insert coins.")
        try:
            d = int(input("how many large dollars?: ") or "0")
            h = int(input("how many half dollars?: ") or "0")
            q = int(input("how many quarters?: ") or "0")
            n = int(input("how many nickels?: ") or "0")
        except ValueError:
            d = h = q = n = 0
        total = d * 1.0 + h * 0.5 + q * 0.25 + n * 0.05
        return round(total + 1e-9, 2)

    def transaction_result(self, coins: float, cost: float) -> bool:
        if coins < cost - 1e-9:
            print("Sorry that's not enough money. Money refunded.")
            return False
        change = round(coins - cost, 2)
        if change > 0:
            print(f"Here is ${change} in change.")
        return True
